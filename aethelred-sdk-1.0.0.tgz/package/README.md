# Aethelred SDK

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.0+-blue.svg)](https://www.typescriptlang.org/)

**Enterprise-grade TypeScript SDK** for the Aethelred blockchain - a sovereign L1 for cryptographically verified AI computations.

## ✨ Features

- 🔗 **Connection Pooling** - Automatic failover with health checks
- 🛡️ **Error Handling** - Comprehensive errors with recovery suggestions
- 📊 **Built-in Caching** - LRU cache with TTL and tag-based invalidation
- 🔄 **Retry Logic** - Exponential backoff with circuit breaker
- 🔔 **Real-time Events** - WebSocket subscriptions for live updates
- 🏗️ **Fluent Builders** - Intuitive API for complex requests
- 📝 **Full TypeScript** - Strict typing with intellisense
- 🔐 **Cryptography** - Hash functions, Merkle trees, commitments

## 📦 Installation

```bash
npm install /Users/rameshtamilselvan/Downloads/AethelredMVP/sdk/typescript
```

Public npm distribution is pending first registry release.

## 🚀 Quick Start

```typescript
import { AethelredClient, builders } from '@aethelred/sdk';

// Connect to testnet
const client = await AethelredClient.connectToNetwork('testnet');

// Check connection
const status = await client.getStatus();
console.log('Connected:', status.connected);
console.log('Block Height:', status.blockHeight);

// Use fluent builders
const loanRequest = builders.loan()
  .personal()
  .amount(25000)
  .termYears(3)
  .goodCredit()
  .build();

// Score with verification
const result = await client.creditScoring.scoreVerified(loanRequest);
console.log('Credit Score:', result.score);
console.log('Decision:', result.decision);
console.log('Seal ID:', result.sealId);
```

## 📖 Table of Contents

- [Configuration](#configuration)
- [Client Options](#client-options)
- [Modules](#modules)
  - [Seal Module](#seal-module)
  - [Compute Module](#compute-module)
  - [Verify Module](#verify-module)
  - [Credit Scoring Module](#credit-scoring-module)
- [Builders](#builders)
- [Event System](#event-system)
- [Error Handling](#error-handling)
- [Caching](#caching)
- [Cryptography](#cryptography)
- [Logging](#logging)
- [Examples](#examples)

## ⚙️ Configuration

### Network Presets

```typescript
// Testnet (recommended for development)
const client = await AethelredClient.connectToNetwork('testnet');

// Mainnet
const client = await AethelredClient.connectToNetwork('mainnet');

// Local development
const client = await AethelredClient.connectToNetwork('local');
```

### Custom Configuration

```typescript
const client = await AethelredClient.connect({
  rpcUrl: 'https://custom-rpc.example.com',
  restUrl: 'https://custom-api.example.com',
  chainId: 'aethelred-custom-1',
  gasPrice: '0.025uaeth',
});
```

### With Signer (for transactions)

```typescript
import { DirectSecp256k1HdWallet } from '@cosmjs/proto-signing';

// From mnemonic
const client = await AethelredClient.connectWithMnemonic(
  { chainId: 'aethelred-testnet-1', rpcUrl: '...' },
  'your mnemonic here...'
);

// From wallet
const wallet = await DirectSecp256k1HdWallet.fromMnemonic(mnemonic, {
  prefix: 'aethelred',
});
const client = await AethelredClient.connectWithSigner(config, wallet);
```

## 🔧 Client Options

```typescript
const client = await AethelredClient.connect(config, {
  // Enable connection pooling for high availability
  enablePooling: true,
  poolSize: 3,

  // Enable caching for better performance
  enableCaching: true,
  cacheTTLMs: 30000,

  // Enable automatic retries
  enableRetries: true,
  retryConfig: {
    maxRetries: 3,
    baseDelayMs: 1000,
    strategy: 'exponential',
  },

  // Enable circuit breaker for fault tolerance
  enableCircuitBreaker: true,

  // Enable WebSocket for real-time events
  enableWebSocket: true,

  // Logging
  logLevel: LogLevel.INFO,

  // Request timeout
  requestTimeoutMs: 30000,

  // Custom headers
  headers: {
    'X-API-Key': 'your-api-key',
  },
});
```

## 📦 Modules

### Seal Module

Digital Seals provide cryptographic proof of AI computations.

```typescript
// Get a seal
const seal = await client.seal.getSeal('seal-123');

// Verify a seal
const verification = await client.seal.verifySeal('seal-123', 'comprehensive');
console.log('Valid:', verification.valid);
console.log('Integrity:', verification.integrityValid);
console.log('Signatures:', verification.signaturesValid);

// Quick verify
const isValid = await client.seal.quickVerify('seal-123');

// List seals with filters
const seals = await client.seal.listSeals({
  status: 'active',
  modelHash: 'abc123...',
  limit: 10,
});

// Iterate over all seals
for await (const seal of client.seal.iterateSeals({ status: 'active' })) {
  console.log(seal.id);
}

// Stream new seals in real-time
const unsubscribe = client.seal.streamSeals({}, (seal) => {
  console.log('New seal:', seal.id);
});

// Create a seal (requires signer)
const response = await client.seal.createSeal({
  modelHash: '...',
  inputHash: '...',
  outputHash: '...',
  purpose: 'credit_scoring',
});

// Generate audit report
const audit = await client.seal.generateAuditReport({
  sealId: 'seal-123',
  format: 'full',
  includeEvidence: true,
});
```

### Compute Module

Submit AI computation jobs for verified execution.

```typescript
// Submit a job
const response = await client.compute.submitJob({
  modelHash: 'abc123...',
  inputHash: 'def456...',
  purpose: 'credit_scoring',
  proofType: 'hybrid',
  priority: 'normal',
});

// Wait for completion
const job = await client.compute.waitForCompletion(response.jobId, 60000);
console.log('Status:', job.status);
console.log('Output:', job.result?.outputHash);

// Submit and wait in one call
const completedJob = await client.compute.submitAndWait({
  modelHash: '...',
  inputHash: '...',
  purpose: 'fraud_detection',
});

// Get queue status
const queue = await client.compute.getQueueStatus();
console.log('Pending:', queue.pendingJobs);
console.log('Wait time:', queue.estimatedWaitTimeMs);

// List registered models
const models = await client.compute.listModels({ status: 'active' });
```

### Credit Scoring Module

Financial AI demo for investor presentations.

```typescript
// Score a loan application
const result = await client.creditScoring.score({
  applicantId: 'app-001',
  loanType: 'personal',
  loanAmount: 25000,
  loanTermMonths: 36,
  features: {
    paymentHistory: 0.95,
    creditUtilization: 0.30,
    // ... other features
  },
});

// Score with verification (creates Digital Seal)
const verified = await client.creditScoring.scoreVerified({
  // ... same as above
});
console.log('Seal ID:', verified.sealId);

// Use sample profiles
const features = client.creditScoring.createSampleFeatures('excellent');

// Run demo scenarios
const scenarios = await client.creditScoring.listScenarios();
const result = await client.creditScoring.runScenario('excellent-credit', true);

// Get metrics
const metrics = await client.creditScoring.getMetrics();
console.log('Average Score:', metrics.averageScore);
```

## 🏗️ Builders

Fluent builders for constructing complex requests.

### Seal Builder

```typescript
import { builders } from '@aethelred/sdk';

const sealRequest = builders.seal()
  .model('abc123...')
  .input({ features: { ... } })
  .output({ score: 750, decision: 'approved' })
  .purpose('credit_scoring')
  .metadata('version', '1.0')
  .regulatory('SOC2', true)
  .build();
```

### Compute Job Builder

```typescript
const jobRequest = builders.job()
  .model('abc123...')
  .input({ features: { ... } })
  .purpose('fraud_detection')
  .hybrid()  // TEE + zkML
  .high()    // High priority
  .maxWait(60)
  .callback('https://api.example.com/callback')
  .build();
```

### Credit Features Builder

```typescript
const features = builders.features()
  .paymentHistory(0.95)
  .utilization(0.30)
  .historyYears(7)
  .diverseMix()
  .cleanRecord()
  .income(85000)
  .build();

// Or use presets
const excellent = builders.features().excellent().build();
const good = builders.features().good().build();
const fair = builders.features().fair().build();
```

### Loan Application Builder

```typescript
const application = builders.loan()
  .applicant('user-123')
  .personal()
  .amount(25000)
  .termYears(3)
  .withVerification()
  .configureFeatures(f => f
    .paymentHistory(0.95)
    .lowUtilization()
    .stableEmployment()
  )
  .build();
```

## 🔔 Event System

Subscribe to real-time events.

```typescript
import { AethelredEventType } from '@aethelred/sdk';

// Subscribe to events
const subscription = client.on(AethelredEventType.SEAL_CREATED, (event) => {
  console.log('New seal:', event.sealId);
});

// Subscribe once
client.once(AethelredEventType.TX_CONFIRMED, (event) => {
  console.log('TX confirmed:', event.txHash);
});

// Wait for event
const event = await client.waitFor(
  AethelredEventType.JOB_COMPLETED,
  30000
);

// Unsubscribe
subscription.unsubscribe();

// Available events
AethelredEventType.CONNECTED
AethelredEventType.DISCONNECTED
AethelredEventType.NEW_BLOCK
AethelredEventType.TX_SUBMITTED
AethelredEventType.TX_CONFIRMED
AethelredEventType.SEAL_CREATED
AethelredEventType.SEAL_VERIFIED
AethelredEventType.JOB_SUBMITTED
AethelredEventType.JOB_COMPLETED
```

## 🛡️ Error Handling

Comprehensive error handling with recovery suggestions.

```typescript
import {
  AethelredError,
  AethelredErrorCode,
  isAethelredError,
  Errors
} from '@aethelred/sdk';

try {
  const seal = await client.seal.getSeal('invalid-id');
} catch (error) {
  if (isAethelredError(error)) {
    console.log('Code:', error.code);
    console.log('Message:', error.message);
    console.log('Retryable:', error.isRetryable);
    console.log('Suggestions:', error.metadata.suggestions);

    // Handle specific errors
    switch (error.code) {
      case AethelredErrorCode.SEAL_NOT_FOUND:
        // Handle missing seal
        break;
      case AethelredErrorCode.RATE_LIMITED:
        // Wait and retry
        await sleep(error.retryAfterMs);
        break;
      case AethelredErrorCode.NO_SIGNER:
        // Connect with wallet
        break;
    }
  }
}

// Error factories
throw Errors.sealNotFound('seal-123');
throw Errors.noSigner();
throw Errors.insufficientFunds('1000000', '500000');
```

## 📊 Caching

Built-in caching with LRU eviction.

```typescript
import { Cache, globalCache, memoize } from '@aethelred/sdk';

// Use global cache
globalCache.set('key', value, { ttlMs: 60000 });
const value = globalCache.get('key');

// Create custom cache
const cache = new Cache({
  maxEntries: 1000,
  maxSize: 50 * 1024 * 1024, // 50MB
  defaultTTLMs: 5 * 60 * 1000,
  evictionStrategy: 'lru',
});

// Cache with tags
cache.set('seal:123', seal, {
  ttlMs: 60000,
  tags: ['seal', 'model:abc']
});

// Invalidate by tag
cache.invalidateByTag('model:abc');

// Get or set pattern
const data = await cache.getOrSet('key', async () => {
  return await fetchData();
}, { ttlMs: 30000 });

// Memoize functions
const memoizedFn = memoize(expensiveFunction, { ttlMs: 60000 });

// Client cache control
client.clearCache();
client.invalidateCache('seal');
const stats = client.getCacheStats();
```

## 🔐 Cryptography

Advanced cryptographic utilities.

```typescript
import { crypto } from '@aethelred/sdk';
// or
import { sha256Hex, buildMerkleTree, createCommitment } from '@aethelred/sdk';

// Hashing
const hash = crypto.sha256Hex('data');
const hash3 = crypto.hashHex('data', 'sha3-256');
const jsonHash = crypto.hashJSON({ key: 'value' });

// Commitments
const { commitment, salt } = crypto.createCommitment('secret');
const valid = crypto.verifyCommitment('secret', { commitment, salt, algorithm: 'sha256' });

// Merkle trees
const root = crypto.buildMerkleTree(['a', 'b', 'c', 'd']);
const proof = crypto.createMerkleProof(['a', 'b', 'c', 'd'], 1);
const verified = crypto.verifyMerkleProof(proof);

// Encryption
const key = crypto.deriveKey('password', 'salt');
const encrypted = crypto.encrypt('sensitive data', key);
const decrypted = crypto.decrypt(encrypted, key);

// Random generation
const bytes = crypto.generateRandomBytes(32);
const hex = crypto.generateRandomHex(64);
const num = crypto.generateRandomNumber(1, 100);

// Secure comparison
const equal = crypto.constantTimeEqual(hash1, hash2);
```

## 📝 Logging

Structured logging with multiple transports.

```typescript
import {
  configureLogger,
  LogLevel,
  ConsoleTransport,
  JSONTransport,
  getLogger
} from '@aethelred/sdk';

// Configure logging
configureLogger({
  level: LogLevel.DEBUG,
  transports: [
    new ConsoleTransport(true), // with colors
    new JSONTransport(),
  ],
});

// Create module logger
const logger = getLogger('my-module');
logger.info('Operation completed', { duration: 100 });
logger.error('Operation failed', new Error('reason'));

// Time operations
const result = await logger.timeAsync('fetch data', async () => {
  return await fetchData();
});
```

## 📚 Examples

### Basic Usage

```typescript
import { connectTestnet, LogLevel } from '@aethelred/sdk';

async function main() {
  const client = await connectTestnet({
    logLevel: LogLevel.DEBUG,
  });

  const status = await client.getStatus();
  console.log('Connected to:', status.chainId);
  console.log('Block height:', status.blockHeight);

  // Query seals
  const seals = await client.seal.listSeals({ limit: 5 });
  console.log('Recent seals:', seals.total);

  client.disconnect();
}
```

### Credit Scoring Demo

```typescript
import { AethelredClient, builders } from '@aethelred/sdk';

async function creditScoringDemo() {
  const client = await AethelredClient.connectToNetwork('testnet');

  // Build loan application
  const application = builders.loan()
    .personal()
    .amount(50000)
    .termYears(5)
    .excellentCredit()
    .build();

  // Score with verification
  const result = await client.creditScoring.scoreVerified(application);

  console.log('Credit Score:', result.score);
  console.log('Category:', result.scoreCategory);
  console.log('Decision:', result.decision);
  console.log('Confidence:', result.confidence);
  console.log('Seal ID:', result.sealId);

  // Verify the seal
  if (result.sealId) {
    const valid = await client.seal.quickVerify(result.sealId);
    console.log('Seal verified:', valid);
  }

  client.disconnect();
}
```

### Streaming Events

```typescript
import { AethelredClient, AethelredEventType } from '@aethelred/sdk';

async function streamingExample() {
  const client = await AethelredClient.connect(config, {
    enableWebSocket: true,
  });

  // Listen for new blocks
  client.on(AethelredEventType.NEW_BLOCK, (block) => {
    console.log('New block:', block.height);
  });

  // Listen for seal events
  client.on(AethelredEventType.SEAL_CREATED, (event) => {
    console.log('New seal:', event.sealId);
  });

  // Stream seals in real-time
  client.seal.streamSeals({ status: 'active' }, (seal) => {
    console.log('Seal update:', seal.id, seal.status);
  });
}
```

## 🔗 Links

- [Documentation](https://docs.aethelred.io/sdk)
- [API Reference](https://docs.aethelred.io/api)
- [GitHub](https://github.com/aethelred/aethelred-sdk)
- [Discord](https://discord.gg/aethelred)
- [Examples](https://github.com/aethelred/aethelred-sdk/tree/main/examples)

## 📄 License

MIT License - see [LICENSE](LICENSE) for details.

---

Built with ❤️ by [Aethelred Labs](https://aethelred.io)
